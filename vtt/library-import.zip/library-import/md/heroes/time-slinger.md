## Alias

Jim Brooks

## Background / Power Source / Archetype / Personality

Anachronistic / Tech Upgrades / Reality Shaper / Lone Wolf

## Principles

Principle of the Time Traveler; Principle of Whispers.

## Biography

A frontier lawman flung through time, rebuilt by AI CON with chronal tech after his body was lost. Fought OblivAeon; now teaches at Freedom Plaza.

## Data note

This is the canonical worked example threaded through the hero-creation rules reference (Backgrounds/PowerSources/Archetypes/Personality/RedAbilities) — the full build chain is documented there if you want the step-by-step reasoning behind these numbers.
