## Alias

Brandon Bradley

## Team

Daybreak

## Background / Power Source / Archetype / Personality

Struggling / Relic / Transporter / Fast Talking

## Principles

Principle of the Mask; Principle of Speed.

## Biography

Became a courier to help pay family debts; ambushed by demonic bugs while delivering a package, discovered a relic granting frictionless-motion powers. Privately worries he's the only Daybreak member without an innate power.
