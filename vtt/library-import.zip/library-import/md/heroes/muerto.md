## Alias

Thiago Diaz

## Team

Daybreak

## Background / Power Source / Archetype / Personality

Adventurer / Supernatural / Divided: Form-Changer / Jaded

## Principles

Principle of the Gearhead; Principle of the Mask.

## Biography

Died as a teenager when OblivAeon destroyed Freedom Tower during a school trip; his consciousness latched onto tech wreckage (Wraith/Tachyon/Bunker parts) instead of passing on, driven by his wish to be a hero.

## Auxiliary Sheet — Forms

Divided hero: Ghost form vs. Electronics forms (Tough/Miniscule in Green, Towering in Yellow/Red — Towering swaps Part Detachment to d12, Awareness to d6). Full per-form power lists are in the original file if needed later.
