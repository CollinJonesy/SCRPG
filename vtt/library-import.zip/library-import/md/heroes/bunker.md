## Alias

Captain Tyler Vance

## Background / Power Source / Archetype / Personality

Military / Powered Suit / Modular: Armored / Decisive

## Principles

Principle of the Defender; Principle of the Tactician.

## Biography

Combat veteran selected to pilot an experimental armored exosuit. After his original suit was lost during OblivAeon, he and Tachyon developed a new modular suit reconfigurable via satellite-delivered upgrade modules.

## Modular Modes (Auxiliary Sheet)

Operations (default), Out of Suit, Utility (Green); Recharge, Tactical (Yellow); Turret (Red). Exact per-mode die values for Power Suit etc. were not fully legible in the source — flagged for verification against page 310 before relying on them.
