## Alias

Maia Adrianna Montgomery

## Background / Power Source / Archetype / Personality

Upper Class / Training / Shadow / Analytical

## Principles

Principle of the Detective; Principle of Stealth.

## Biography

Survived a violent assault in college (her boyfriend was killed); became a vigilante protector. CEO of Montgomery Industries, member of the Sentinels of Freedom, in a relationship with Bunker (Tyler Vance).

## Data note

This entry was transcribed in an abbreviated format (no per-zone ability tables) — mechanical Powers/Qualities/Health are complete and imported; full ability text was not in the source file.
