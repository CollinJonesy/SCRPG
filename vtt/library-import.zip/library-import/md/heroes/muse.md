## Alias

Vanessa Long

## Team

Daybreak

## Background / Power Source / Archetype / Personality

Former Villain / The Multiverse / Psychic / Nurturing

## Principles

Principle of Mastery; Principle of the Inner Demon.

## Biography

Taken at birth by a program seeking to weaponize psychic children, rescued as an infant. Latent powers surged uncontrollably as a teen, manifesting nightmares; sent to Freedom Academy hoping for acceptance.
