## Alias

Megan "The Hammer" Lee

## Team

Daybreak

## Background / Power Source / Archetype / Personality

Unremarkable / Accident / Physical Powerhouse / Arrogant

## Principles

Principle of Ambition; Principle of Strength.

## Biography

An accidental fall at a dig site left rock fused to her skin, granting superhuman strength and a stone-like covering. Enrolled at Freedom Academy as both hero-in-training and aspiring rock star.

## Data flag

Source table shows Stone's die with some ambiguity between an icon and the number 12 — imported as d8 (the value printed in the reference table); worth a page check if you have the physical book handy.
