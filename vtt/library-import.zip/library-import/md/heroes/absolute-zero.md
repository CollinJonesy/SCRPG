## Alias

Ryan Frost

## Background / Power Source / Archetype / Personality

Tragic / Accident / Elemental Manipulator / Sarcastic

## Principles

Principle of Dependence (reliant on coolant suit); Principle of Cold (affinity for cold).

## Biography

Ryan Frost's fiancée was killed by a drunk driver; adrift afterward, an industrial accident at a cryogenics facility doused him in coolant, transforming his biology and leaving him in stasis for years until revived by Tachyon. Now teaches ethics and philosophy at Freedom Academy.

## Costume/Equipment

White, blue, and carbon-black coolant suit; glowing blue faceplate; palm apertures; chest vents.
