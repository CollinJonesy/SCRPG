## Alias

Dr. Meredith Stinson

## Background / Power Source / Archetype / Personality

Academic / Radiation / Speedster / Inquisitive

## Principles

Principle of Speed; Principle of Science.

## Biography

Patented HUD display tech in college; an experiment exposed her to tachyon particles, granting super-speed. Nearly lost her life to overexertion during OblivAeon before learning to pace herself; now teaches at Freedom Academy.
