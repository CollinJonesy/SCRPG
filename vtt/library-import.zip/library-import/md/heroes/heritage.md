## Alias

Paul Parsons

## Background / Power Source / Archetype / Personality

Dynasty / Genetic / Physical Powerhouse / Natural Leader

## Principles

Principle of Order; Principle of the Mentor.

## Biography

Latest in the multigenerational "Legacy" line. Passed the Legacy name to his daughter Felicia after OblivAeon and took up the Heritage identity to focus on mentorship at Freedom Academy; U.S. representative to G.L.O.B.A.L.
