## Alias

Pauline "Felicia Fields" Parsons

## Background / Power Source / Archetype / Personality

Dynasty / Genetic / Flyer / Cheerful

## Principles

Principle of the Hero; Principle of Justice.

## Biography

Daughter of the original Legacy (Heritage). Fought alongside her father and the Freedom Five against OblivAeon; stepped fully into the Legacy identity afterward. Juggles hero work, mentoring at the Academy, and a nonprofit job.
