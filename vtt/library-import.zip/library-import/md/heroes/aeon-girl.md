## Alias

Windy Farrum

## Team

Daybreak

## Background / Power Source / Archetype / Personality

Blank Slate / Higher Power / Blaster / Naive

## Principles

Principle of Levity (unbreakable positive outlook); Principle of Cosmic Energy.

## Biography

Formed when Lifeline absorbed and redirected Aeon Master's cosmic energy during OblivAeon, channeling it into an entirely new sentient being. Only a few months old, still learning what it means to be a person by observing those around her.
