## Alias

Gabrielle Adhin

## Team

Slaughterhouse Six

## Biography

Grew up hearing about her family's legendary luck; discovered she could manipulate probability, but pulling luck toward herself always created backlash elsewhere — which she learned to redirect onto others.

## Capabilities & Motivations

Alters probability at her opponents' expense. Practiced at managing the waves of luck/unluck to her own benefit.

## Upgrades

Will use her powers on herself in the most dire situations, though broad use gives heroes more chances for things to go wrong.

## Data note

Uses a Health-zone status track (Green/Yellow/Red) — GreenFloor/YellowFloor/RedFloor are populated and meaningful for this one.
