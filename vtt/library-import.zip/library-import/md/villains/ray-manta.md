## Alias

Raymond Mantey (paranoid about revealing it)

## Team

Slaughterhouse Six

## Biography

RevoCorp weapon developer, a paranoid conspiracy theorist transferred to the active villain wing for being too strange/useful; joined Ambuscade/Slaughterhouse Six. Wears tin-foil armor.

## Capabilities

Anti-robot tech specialist; semi-autonomous "Manta Body" suit upgrade available.
