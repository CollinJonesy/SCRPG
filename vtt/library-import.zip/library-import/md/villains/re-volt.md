## Alias

Sean Vargas

## Team

Slaughterhouse Six

## Biography

RevoCorp enforcer betrayed by scientist Demikahv, overloaded with power; his body was destroyed and he became a cloud of electrically-charged ash. Joined Slaughterhouse Six seeking purpose and a connection to humanity.

## Capabilities

No physical body; can travel over wires; absorbs electricity for power augmentation.

## Upgrades

Neural Takeover — reduces heroes' quality dice by zone; can control knocked-out heroes' bodies.
