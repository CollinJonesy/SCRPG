## Alias

Steven Graves

## Biography

Military veteran and rival to Bunker (Tyler Vance); discharged after a combat wound, underwent bio/mechanical modifications. Now hired muscle; partners with Ermine on heists.

## Data note

Uses a Health-zone status track (Green/Yellow/Red) rather than a condition-based track — GreenFloor/YellowFloor/RedFloor are populated and meaningful for this one.
