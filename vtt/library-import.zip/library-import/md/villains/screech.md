## Alias

Damien Belter

## Band

Helfyre (vocalist)

## Biography

Never grasped the concept of an 'inside voice'; cycled through bands before landing with a group who all had some measure of power and a shared feeling of destiny.

## Capabilities & Motivations

Vocal instrument expanded well beyond human limits — an unhinged jaw and altered lungs. Uses his voice as a weapon on stage and off.

## Upgrades

Wager Master's boost expanded his range: shrill notes that shatter glass, bass tones that shake stone, and full sonic walls that knock down doors and helicopters.
