## Alias

Aislin Allen

## Team

Slaughterhouse Six (leader)

## Biography

Formerly a hero (the Shrieker) alongside the first Freedom Five; faked her death after her throat was wounded and her powers faded. Baron Blade offered her illusion-powers in exchange for a favor.

## Capabilities & Motivations

Master of multilayered planning who prefers working behind the curtain — secretly ran the previous Slaughterhouse Six through the illusory figurehead Ambuscade.

## Upgrades

Working on tailoring illusions to specific individuals within a crowd rather than one shared illusion.
