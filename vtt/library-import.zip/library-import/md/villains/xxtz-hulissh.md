## Alias

None

## Biography

Ancient Atlantean mages, unable to destroy it, sacrificed their own city to forge twelve relics anchoring it in place. Several relics have since been removed, weakening the seal.

## Capabilities & Motivations

Biology, motives, and weaknesses nearly impossible to discern; merely looking upon it risks madness.

## Data note

Titan's Challenge status track uses checkbox tiers in the source rather than a simple condition count — imported as best-effort into the Status slots, but this one genuinely needs your read on how you want to run the checkbox mechanic at the table before treating the die values as authoritative.
