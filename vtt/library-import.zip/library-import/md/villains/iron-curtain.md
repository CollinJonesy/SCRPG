## Alias

Barrikada Dmitriyevna Petrov

## Team

Perestroika

## Biography

Second to bear the name — her father held the title before her. As the Soviet Union crumbled he spiraled into depression; with his dying words, urged her toward a better path. Mecha-Stalin's promise proved irresistible.

## Capabilities & Motivations

Metallic flesh grants immense strength and durability but greatly reduces touch/taste. Seeks to feel something again through a real fight.

## Upgrades

Mecha-Stalin's electrified exoskeleton makes her more dangerous in close combat; she welcomes the intensity.
