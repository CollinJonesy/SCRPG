## Alias

Zosimos Alchemista

## Biography

The original alchemist Zosimos of Panopolis secured immortality through manipulation of flesh, eventually building realistic 'fleshchild' simulacra to gather secrets and impersonate heroes. Not seen since his defeat by Writhe.

## Capabilities & Motivations

Master of indirect plots run from behind the scenes; fleshchildren can be identical to the original down to believing they ARE the original.

## Upgrades

Fleshchild process improved to be more realistic and durable.
