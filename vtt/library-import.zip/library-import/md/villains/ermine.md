## Alias

Cassandra Lilya

## Biography

Learned crime paid well; a high-profile museum heist brought her into conflict with Wraith, who exposed her secret identity. Recruited into Baron Blade's Vengeful Five out of resulting hatred for Wraith; now freelances.

## Capabilities & Motivations

Self-centered, rarely plans beyond what catches her eye — the thrill of theft is what excites her. Lately teaming up with Fright Train.

## Upgrades

Traded a utility belt for gem-based gadgets granting temporary invisibility, holograms, and laser deflection.
