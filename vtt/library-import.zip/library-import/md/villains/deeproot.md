## Alias

Silvio Thorne

## Band

Helfyre (bass)

## Biography

A sprawling, strange life — communing with plants in a remote valley, surviving a storm at sea on a raft of kelp, washing ashore in Hawaii — and always eager to tell you about it in exhaustive detail.

## Capabilities & Motivations

Can grow and control plants; the glue holding Helfyre together off-stage, breaking up fights and keeping the group functional.

## Upgrades

Can now make plants grow faster, strengthen them, and revive dead plants.
