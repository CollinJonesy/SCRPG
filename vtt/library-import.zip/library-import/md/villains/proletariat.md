## Alias

Alexandr Tsarev

## Team

Perestroika

## Biography

Exposed to radium in WWII, gaining the ability to duplicate himself; frozen by Soviets and thawed decades later. Tricked by Baron Blade into fighting the Freedom Five; now serves Mecha-Stalin.

## Capabilities

Distributes consciousness across clones — no single "main" body.

## Data note

Vitality was listed under Qualities in the source (rather than Powers); imported as-shown rather than reclassified, since I can't confirm which is correct without the physical page.
