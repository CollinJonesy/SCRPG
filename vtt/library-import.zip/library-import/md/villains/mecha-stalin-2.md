## Alias

Joseph Stalin? (origin unclear)

## Team

Perestroika

## Biography

Reappeared in Siberia months after Mecha-Stalin 1's defeat, in a streamlined new body with new followers. Abandoned the America-takeover plan in favor of Soviet Union reunification; freed and re-equipped Perestroika.

## Data note

Second/later Mecha-Stalin body — uses a Health-zone status track (Green/Yellow/Red), unlike the first body which used a condition-count track. Same character across time, kept as a separate villain entry since the stat blocks differ.
