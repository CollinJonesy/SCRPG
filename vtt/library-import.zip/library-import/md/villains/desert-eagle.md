## Alias

Mikal Jadoon

## Team

Slaughterhouse Six

## Biography

Abandoned the Pakistani army for mercenary pay, then joined RevoCorp's black ops team. A terrifying encounter with something like living darkness pulled him in by the eyes; Ray Manta fixed his resulting vision problems weeks later.

## Capabilities & Motivations

Skilled aerial combatant; Eagle Eye system analyzes target weaknesses the longer a fight continues.

## Upgrades

Ray Manta continually tinkers with his gear — next-gen targeting, stronger barriers, tighter turns.
