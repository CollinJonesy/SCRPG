## Alias

Pavel Vladislavovich Koslovski

## Team

Perestroika

## Age

97 years old

## Biography

Red Army veteran of Stalingrad; NKVD sleeper operative activated in 1950, placed in Bolivia for 13 years before reactivation by Mecha-Stalin.

## Capabilities & Motivations

History's greatest sniper — decades of practice, extreme-range calculation, unmatched patience. Stalks targets for days.

## Upgrades

Exoskeleton upgrade from Mecha-Stalin.
