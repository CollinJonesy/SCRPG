## Alias

"Jasper Felwind" (admits to no other name)

## Band

Helfyre (manager, honorary member)

## Biography

Sought immortality by taking the place of a chosen 'king' in a mysterious Romanian festival, bargaining his way into the vampiric Court of Blood — then fled after years of menial servitude.

## Capabilities & Motivations

Speed, strength, and enthralling presence of a vampire, but manipulation is his greatest asset. Wants immortal luxury; fears the Court of Blood catching up to him.

## Upgrades

Barely scratched the surface of blood magic, aware Snare has taken an interest in the same subject.
