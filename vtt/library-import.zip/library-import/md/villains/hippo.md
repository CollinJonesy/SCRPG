## Alias

Eddie Wagner

## Team

Slaughterhouse Six

## Biography

Liked hitting things, being bigger than what he hit, and money. Got all three as a thuggish enforcer-style baseball player, then leaned into muscle-growth drugs until he became hired muscle.

## Capabilities & Motivations

The suit's liquid-armor 'skin' turns aside nearly anything. Content to serve as the Slaughterhouse Six's blunt instrument.

## Upgrades

Pharmacology pushed to its limit; cybernetic enhancements from Ray Manta could multiply his strength further.

## Data note

Uses a Health-zone status track (Green/Yellow/Red) — GreenFloor/YellowFloor/RedFloor are populated and meaningful for this one.
