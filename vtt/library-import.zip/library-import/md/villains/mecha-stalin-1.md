## Alias

Joseph Stalin? (origin unclear)

## Team

Perestroika

## Biography

In-universe origin genuinely unresolved: theories range from Cold War cloning to an actual preserved brain in a Soviet mechanical body. Masterminded Perestroika's formation around restoring the Soviet cause.

## Capabilities

Patchwork mechanical body — flamethrower, crushing hand, autocannon. Mechanical brain retains strategic instincts and personality-cult charisma.

## Data note

This is the first of two documented Mecha-Stalin bodies — see also "Mecha-Stalin 2" as a separate villain entry, same character, later incarnation.
