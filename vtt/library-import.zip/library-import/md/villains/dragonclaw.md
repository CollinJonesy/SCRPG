## Alias

Sophia DeLeon

## Biography

Served a string of masters; the mystic Zhu Long resurrected her after her second master had her killed, teaching her poison, magic, and martial arts in exchange for service as his agent.

## Capabilities & Motivations

Among the most capable hand-to-hand combatants in the world. Constantly tests the limits of Zhu Long's control, aware he always watches; loyalty remains out of necessity, not choice.

## Upgrades

Forged The Jade Talon herself — a stone blade doubling as weapon and magical focus, letting her animate her tattoos to fight alongside her.
