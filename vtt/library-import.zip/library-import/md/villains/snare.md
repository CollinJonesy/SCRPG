## Alias

Lilith Black

## Band

Helfyre (drums)

## Biography

Grew up with a disability; an experimental clinic offered a hoverchair in exchange for a risky treatment. Overheard staff planning to dispose of her, and something in her mind snapped, manifesting a shield of red energy.

## Capabilities & Motivations

Shields are a versatile form of telekinesis, used as both instruments and weapons. The driving force behind Helfyre's cohesion on and off stage.

## Upgrades

Fully committed to Helfyre, drawn toward learning more about the mysterious Drudge.
