## Alias

Cinder Azarian

## Band

Helfyre (lead guitar)

## Biography

Grew up on tour, daughter of a roadie. Powers manifested when her fingers touched guitar strings and burst into flame; discovered she was immune to fire.

## Capabilities & Motivations

By far the most musically skilled member of Helfyre; genuinely talented and driven to improve, but not interested in helping the others improve.

## Upgrades

Wager Master's boost increased her control, letting her produce hotter, more sustained fire effects.

## Data note

Uses a Health-zone status track (Green/Yellow/Red like heroes) rather than a condition-based track — GreenFloor/YellowFloor/RedFloor are populated and meaningful for this one.
