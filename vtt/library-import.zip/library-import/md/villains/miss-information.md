## Alias

Aminia Twain

## Biography

Died hating the Freedom Five after years of quietly serving as their secretary. A timespace fracture placed her consciousness into an alternate reality's version of herself; reborn with reality-warping illusion powers.

## Capabilities & Motivations

Master of logistics and intelligence gathering; can warp reality directly when subtlety fails. Only her difficulty maintaining focus keeps her from being a true world-ender.

## Upgrades

Acquired the Pandemonium Key post-OblivAeon, enhancing her illusion-reality powers.
