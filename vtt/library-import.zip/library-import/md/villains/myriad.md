## Alias

Edgar Black

## Biography

Enjoyed exterminating small creatures. A vehicle crash freed a trapped demonic entity, which possessed Black and multiplied into the composite personality Myriad.

## Capabilities

Demonic swarm; near-unlimited sensory reach; reckless, chaos-seeking; flexible forms from single fly to sky-blackening swarm.

## Data note

Status track is unusual: always d8 regardless of minion count (an Overlord archetype variant, per the source).
