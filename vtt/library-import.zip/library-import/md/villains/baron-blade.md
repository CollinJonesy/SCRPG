## Alias

Ivan (Grigori) Ramonat

## Nation

Mordengrad

## Biography

Fyodor Ramonat's weapons factories were destroyed by Legacy's forerunners; his son Ivan seized Mordengrad and declared himself its ruler as Baron Blade, waging schemes against heroes ever since, especially the Legacy line.

## Capabilities & Motivations

Prolific inventor of doomsday devices, backed by the loyal Blade Battalion army. Core goals: defend/elevate Mordengrad, destroy Legacy.

## Upgrades

Favors powered suits, from walking tanks to sleek body armor, customized per scheme.
