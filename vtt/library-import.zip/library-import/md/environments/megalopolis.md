## Source page

420-421

## Overview

United States, Connecticut. Population 8.5 million. Founded 1876 as New Colchester, renamed Megalopolis July 4, 1976. 405 sq mi.

## Location Features

Hub of finance, culture, entrepreneurship. Dominated by the massive Akash'Flora tree (OblivAeon remnant, roots through city infrastructure, supplements the power grid). 'Greenest city in the world.' Home to the Sentinels of Freedom, based at Freedom Tower/Freedom Plaza.

## Green Zone — Minor Twists

Public Defenders arrive; Traffic Pileup.

## Green Zone — Major Twist

Hostage Situation challenge.

## Yellow Zone — Minor Twists

Panicking Crowds; Paparazzi on Scene.

## Yellow Zone — Major Twist

Exposed Root System (Lieutenant spawned; destroying it triggers a scene advance).

## Red Zone — Minor Twists

Impending Casualty; Rioting in Streets.

## Red Zone — Major Twist

Plummeting Monorail challenge.
