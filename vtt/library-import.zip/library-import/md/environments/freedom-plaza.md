## Source page

422-423

## Overview

Sentinels of Freedom Academy of Heroics and Justice. Established 2018. Administrator: Paul Parsons (Heritage). Megalopolis, Connecticut. 960-acre campus, 417 staff, 63 full-time + 109 part-time students. Colors: Blue & Silver. Public hours 9AM-7PM.

## Key Features

Post-OblivAeon training center for next-gen heroes. Sentinels HQ, Tachyon's labs, Legacy Park memorial, the Akash'Flora tree. Tight security on student records.

## Green Zone — Minor Twists

Breakout (minion spawn); Campus Tour, Interrupted.

## Green Zone — Major Twist

Campus Alert (multi-effect scene).

## Yellow Zone — Minor Twists

Class is Cancelled!; Found Arsenal (enemy boost).

## Yellow Zone — Major Twist

A New Hero on the Scene (ally lieutenant spawned; name table on pages 422-423).

## Red Zone — Minor Twists

Containment Failure; Hiding in Training Simulator.

## Red Zone — Major Twist

Experimental Defense System Gone Haywire (multi-target attack/hinder).
