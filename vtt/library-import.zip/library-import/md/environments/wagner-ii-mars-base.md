## Source page

424-425

## Overview

Joint venture of 10 nations. Crew up to 1500, currently posted 857. Linked to Wagner Space Center, Megalopolis via teleportation portal. Nuclear reactor power; portal power source classified.

## Background

The original Wagner Mars base self-destructed during OblivAeon for reasons still classified. Reinstated in 2018 with a teleportation gate network linking Earth and Mars.

## Green Zone — Minor Twists

Energy Flare: Attack one hero Max die, another Mid die; Hinder both with Min die. Sprinkler Malfunction: Hinder closest hero (Max) and closest enemy (Mid); Defend all with Min die.

## Green Zone — Major Twist

Trouble in the Biosphere: 2-success challenge + 3-space timer. If timer runs out, scene tracker advances to the second-to-last space.

## Yellow Zone — Minor Twists

In the Wrong Hands: Boost all enemy lieutenants/villains with Mid die (persistent). Meteor Storm: Attack all with Max die, Hinder all with Mid die. Untimely Interference: introduce minions equal to Max die, sized per Min die.

## Yellow Zone — Major Twist

Oxygen Leak: 2-success challenge to seal; until resolved, scene tracker advances check off two spaces per advance instead of one.

## Red Zone — Minor Twist

Quarantine Breach: Hinder all targets with Mid die (persistent). Source note: only one Red minor twist is present here, unlike most environments which have two.

## Red Zone — Major Twist

Emergency Portal Protocol: 3-space timer; if it runs out before scene end, check off all remaining Scene Tracker spaces.
