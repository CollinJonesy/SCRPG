## Source page

428-429

## Overview

Eastern Europe. Capital: Mordengrad. Leader: Ivan Ramonat (Baron Blade). Government: meritocracy. Population ~40,000 (secretive, no outside census). Currency: Mordengradi Luna. Illegal for anyone named Paul/Pauline to enter (as of 1998).

## Narrative

Baron Blade's absolute-rule nation, repeatedly clashed with Legacy/heroes. Apparent death during OblivAeon; body returned to Mordengrad, rumors of survival persist. Currently recruiting technical/engineering personnel.

## Data note

'Loyal Citizens' trait is variable — its die size always equals the number of heroes in the scene, per the source.

## Green Zone — Minor Twists

Battalion Patrols (Trooper minions); Dance with the Goat.

## Green Zone — Major Twist

Battalion Leader (commander lieutenant).

## Yellow Zone — Minor Twists

Auto-Drone-Deployment; In Memory of the Baron.

## Yellow Zone — Major Twist

Loyalist (lieutenant spawned; name table in source).

## Red Zone — Minor Twists

Watching from Shadows (Covert Trooper minions); The People of Mordengrad challenge.

## Red Zone — Major Twist

All Hands Response (Roboticized Troopers + Walking Tank).
