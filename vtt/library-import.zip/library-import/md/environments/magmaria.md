## Source page

426-427

## Overview

Independent nation, theocracy, ~200,000 sq mi, ~230,000 population. 1802-2188 miles below the crust. Temperature range 129°F-2200°F. Travel Advisory: Red, do not travel.

## Background

Magmarians first appeared on the surface in 1952. Contact was sporadic and violent until Tachyon developed a translation device in 1984 and discovered Magmarians require crystalline compounds to survive — their hostility stemmed from struggling to survive the 'cold' surface world.

## Green Zone — Minor Twists

Very Hot: roll env dice, Hinder targets without fire immunity with Mid die (persistent, exclusive). Magmarian Envoy: introduces an Ember Shaman (page 411); while it's at full die size, Magmarians won't Attack heroes.

## Green Zone — Major Twist

Magma Crystallization: destroy one mod on each target; for each mod destroyed, add a Crystal Collector minion (page 411).

## Yellow Zone — Minor Twists

Incredibly High Temperatures: Attack non-fire-immune targets with Mid die, Hinder with Max die (persistent). Magma Eruption: Attack 3 closest targets with Max die, all others with Mid die.

## Yellow Zone — Major Twist

Structural Collapse: introduce Inner Core Tunneler minions equal to Mid die; advance scene tracker by Min die.

## Red Zone — Minor Twists

Hot Enough to Boil Stone: Attack non-fire-immune targets with Max die, Hinder with Mid+Min dice (persistent). Magmaria at War: introduce Seismic Defender minions equal to # of Ember Shamans in scene; Attack all targets with Max die.

## Red Zone — Major Twist

Ancient Behemoth Rampage: introduce an Ur-Crystal Behemoth (page 412), acts next in the action order.
