## Source page

430-431

## Overview

South Atlantic Ocean, 5698m depth. UNESCO World Heritage Site (designated 2019). ~180 acres total, ~98 accessible. Founding/abandonment date unknown.

## Background

Historians estimate Atlantis predates the earliest known human settlement by thousands of years — its citizens had complex technology while Neanderthals were still using stone tools. The Guardian Kraken patrols the waters; a pressurized water barrier protects a multinational research base.

## Green Zone — Minor Twists

The Kraken Seeks Prey: Hinder 3 targets nearest the barrier with Mid die; introduce Kraken Tentacles (d6) equal to Min die. Water Barrier Disturbances: 2-success challenge to stabilize; -1 penalty to all actions until resolved.

## Green Zone — Major Twist

Activated Pillars: until scene end, increase all Power dice of the nearest hero and villain by one size.

## Yellow Zone — Minor Twists

The Kraken Is Angered: Hinder 3 targets near exits with Max die; introduce Kraken Tentacles (d8) equal to Min die. Forgotten Magics: Hinder a target with Max die (persistent); doubles = Attack instead; triples = Boost instead (persistent).

## Yellow Zone — Major Twist

Water Barrier Fault: 2-success challenge + 3-space timer tied to scene tracker advances. On timer expiry: Attack all targets outside sealed structures with Mid+Min dice, Hinder with Max die (persistent until inside).

## Red Zone — Minor Twists

The Kraken Thrashes: Attack 3 targets near exits with Max+Min dice, Hinder with Max+Mid dice; introduce Kraken Tentacles (d8) equal to Min die. Misapplied Protection: Defend + Boost the most notable enemy with Max/Mid dice (persistent).

## Red Zone — Major Twist

Defensive Impairing Field: 2-success challenge to disable; until resolved, heroes lose all Reaction and Inherent abilities.
