## Source page

408-410

## Description

Who would build a robot this huge? Too big to be done about.

## Ability — Several Stories High / Massive Stomp

+2 to save rolls; while at d12, can be reduced one size by a successful Overcome. Attacks deal damage to all nearby targets.

## Tactics

Stomps toward whatever it's programmed to attack; deploy with a plan in mind.
