## Source page

414-417

## Description

Not particularly good at aiming or gun maintenance, but has a gun and a willingness to use it.

## Ability — Pistols Akimbo

Attack actions can hit up to 3 targets in range.

## Tactics

Gets to a spot to shoot at as many targets as possible, staying out of melee range.
