## Source page

413

## Description

The spawn of the dread xxtz'Hulissh — as varied as leaves from a thousand trees, and incredibly creepy.

## Ability — Gaze of the Archfiend

When taking a Hinder action, may destroy itself to apply the penalty to all non-Hulissh targets that can see it/xxtz'Hulissh.

## Tactics

Not native to this realm; seek to leave quickly by throwing themselves into combat or sacrificing themselves.
