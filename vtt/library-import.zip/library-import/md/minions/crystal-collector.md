## Source page

411

## Description

Tasked with "farming" naturally occurring magma crystals the Magmarian people depend on.

## Ability — Harvest

As an action, remove a bonus or penalty from a nearby target; if its die is lower than a diamond, increase its die size by one.

## Tactics

Not warriors — if pressed, will try to take items from foes in crystal form.
