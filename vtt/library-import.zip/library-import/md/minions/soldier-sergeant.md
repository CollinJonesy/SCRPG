## Source page

414-417

## Description

A military leader directly involved in the conflict, fighting alongside the other soldiers.

## Ability — Know Your Troops / Get Back In There!

Rolls twice and uses higher when Boosting a Grunt. Nearby Grunts at d8 who succeed their save increase die size by one.

## Tactics

Excellent force multiplier for Grunts, both via bonuses and survivability.
