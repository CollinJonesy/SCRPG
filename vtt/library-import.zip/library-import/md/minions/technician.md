## Source page

414-417

## Description

Operating machinery, taking readings, monitoring computers — scientists, not fighters.

## Ability — Specialized

Cannot Attack or Defend, but +3 to Overcome actions.

## Tactics

Flees/cowers in combat, but effective when working a specific job while protected.
