## Source page

406-407

## Description

Very few have ever been seen — that means they're good at their job.

## Ability — Without a Trace

Whenever it acts while unobserved/undetected, roll its die twice and take the higher result.

## Tactics

Get in, get the job done, get out. Prefer cover if forced into a fight.
