## Source page

413

## Description

Biomancer's occasional larger, more powerful creation — no good at blending in, very good at violence.

## Ability — Wall of Flesh

+1 to Attacks and to save rolls.

## Tactics

A blunt instrument for heavy lifting/heavier punching, usually opposing physically powerful threats.
