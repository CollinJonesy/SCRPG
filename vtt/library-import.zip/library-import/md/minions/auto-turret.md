## Source page

408-410

## Description

Sturdy turret, often built into a structure or vehicle, with its own power/ammo supply.

## Ability — Well Built

+1 to minion save rolls; can be destroyed with a successful Overcome.

## Tactics

Shoots at any moving thing not specifically programmed to ignore.
