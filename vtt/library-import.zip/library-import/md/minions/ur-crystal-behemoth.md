## Source page

412

## Description

A more primordial form of the Crystalloid Behemoth, thought extinct, now intent on destroying any living creature.

## Ability — Fire-Eater / From the Stone

Increases its die size by one (max diamond) when it destroys a Magmarian or other heat source. +1 to save rolls.

## Tactics

Hunts down the hottest and most vulnerable targets it can reach.
