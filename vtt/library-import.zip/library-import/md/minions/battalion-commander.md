## Source page

406-407

## Description

Risen through the ranks — an impressive feat given how dangerous life is as a Trooper. Feared for their troops and their own combat skill.

## Ability — Hold The Line / Quick-Deploy Baton

Nearby allied minions get +1 to save and Attack rolls. Whenever the Commander rolls a save, also use that roll as an Attack against a nearby foe.

## Tactics

Stay in the midst of their troops rather than lead from front or back.
