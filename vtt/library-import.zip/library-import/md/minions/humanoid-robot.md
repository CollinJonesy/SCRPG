## Source page

408-410

## Description

Some follow a series of laws and serve their creators; others act like they have free will.

## Ability — Metal Parts

+1 to save rolls.

## Tactics

Jack-of-all-trades; tactics depend entirely on the situation.
