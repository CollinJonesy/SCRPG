## Source page

408-410

## Description

Impossible-seeming max hover height, able to reach the upper atmosphere. Light, carries very little.

## Ability — Observation

Can make an observation-based Boost persistent and exclusive by reducing die size by 1 (min d4).

## Tactics

Stay high above the fight, imparting bonuses and intel without joining the fight.
