## Source page

413

## Description

Very normal-looking people who are, in fact, flesh and metal creations of Biomancer.

## Ability — Blend In

+1 to all actions while not yet exposed as a Fleshchild.

## Tactics

Seek to appear "normal" until discovered/activated; then fight without regard for survival.
