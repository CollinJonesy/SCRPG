## Source page

406-407

## Description

More metal than man — fearsome bionic weapons built into their forms.

## Ability — Battalion Powers

When Hindering a hero or Attacking with a penalty, roll their die twice and use the higher result.

## Tactics

Engage and isolate individual heroes, Hindering first.
