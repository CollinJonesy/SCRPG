## Source page

404-405

## Description

Hard to imagine the type of planet this rock-plated foe originated from — jaws strong enough to crush rocks, an appetite for costumed heroes.

## Ability — Alien Venom

Whenever a Bestial Chomper damages a target, that target gains a -1 penalty.

## Tactics

Fight in packs, letting venom wear opponents down as they try to tear them apart.
