## Source page

404-405

## Description

A floating creature from a place with very different atmosphere and gravity — moves easily despite its unwieldy appearance.

## Ability — Lashing

Whenever it Attacks, roll its die twice and take the lower result; apply that as an attack against all nearby opposed targets.

## Tactics

Naturally loners due to their tendency to lash out — rare and dangerous to find a group.
