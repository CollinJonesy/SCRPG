## Source page

411

## Description

A Magmarian who consumed more than their ration and was exiled as a result.

## Ability — Firebrand

Whenever it Attacks, may Attack 2 nearby targets.

## Tactics

Outcasts searching for any crystalline compounds; lash out at any who draw near.
