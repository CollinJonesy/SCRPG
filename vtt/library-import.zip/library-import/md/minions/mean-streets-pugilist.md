## Source page

414-417

## Description

A big fella with big fists who leans into it.

## Ability — Scrapper

+1 to Attack actions.

## Tactics

All about Attacking; only takes another action if truly necessary.
