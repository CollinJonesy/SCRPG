## Source page

414-417

## Description

Doesn't stoop to fists/clubs/guns — fights with some flair instead.

## Ability — Chain Whipping

+1 to Hinder actions.

## Tactics

Best supported by minions who can exploit penalties; alone, alternates Hinder and Attack.
