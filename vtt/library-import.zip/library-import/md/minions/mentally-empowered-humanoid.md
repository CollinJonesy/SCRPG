## Source page

404-405

## Description

Some alien races have mental aptitude far beyond human comprehension — extreme intelligence and psychic powers.

## Ability — Brain Power

+1 to Hinder or Overcome actions.

## Tactics

Problem solvers rather than combatants; seek to trick opponents rather than match them in violence.
