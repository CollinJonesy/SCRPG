## Source page

414-417

## Description

Well connected, with a handle on social and societal pressures.

## Ability — Extortion

+1 to Overcome, Boost, and Hinder actions when they have sensitive information.

## Tactics

Avoid physical confrontation, preferring social leverage.
