## Source page

411

## Description

Most animalistic of the Magmarians — mole-like but orders of magnitude larger and hotter.

## Ability — Dig Deep

+1 to Hindering by digging.

## Tactics

Move earth/stone fast; build walls to help allies and hinder foes in combat.
