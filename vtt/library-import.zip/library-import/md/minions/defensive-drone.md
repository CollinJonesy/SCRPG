## Source page

408-410

## Description

Sturdy drone that projects a barrier using tech similar to Baron Blade's Mobile Defense Platform.

## Ability — Shield Projector

+2 to Defend actions taken to defend targets other than itself.

## Tactics

Expensive to produce/maintain; used sparingly to defend high-value targets.
