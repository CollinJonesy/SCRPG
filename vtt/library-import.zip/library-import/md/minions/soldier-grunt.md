## Source page

414-417

## Description

A standard military soldier with standard modern gear.

## Ability — Squad Goals

+1 to Attack and Boost actions while near other Soldier Grunts or Sergeants.

## Tactics

Works best in squads or supported by a Sergeant; moves and Boosts as a unit.
