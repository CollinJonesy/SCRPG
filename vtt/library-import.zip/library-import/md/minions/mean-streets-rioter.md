## Source page

414-417

## Description

Might not know exactly what they're lashing out against, but that won't stop them.

## Ability — Molotov

Hinder actions can hit up to 3 nearby targets.

## Tactics

Wants to make as much of a mess as possible; disrupts groups and causes chaos.
