## Source page

413

## Description

Not only too big to be a normal bug, but whispers the names of people you thought you'd forgotten.

## Ability — If You See One

While larger than d4, can use an action to roll its die and add that many d4 Demonoid Insects to the scene.

## Tactics

A single one swarms as often as possible; a group targets whatever seems most digestible.
