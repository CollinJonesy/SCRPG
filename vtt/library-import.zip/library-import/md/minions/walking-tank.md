## Source page

408-410

## Description

No wheels — legs. Tricky locomotion, but handles difficult terrain well.

## Ability — Planted Blast / Walking Target

+2 to Attack against large/slow targets. Rolls save twice and uses higher result if attacked while moving.

## Tactics

Wades into combat, unleashes on easiest targets, blocks attacks against weaker allies.
