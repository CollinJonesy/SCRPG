## Source page

408-410

## Description

The most basic drone — used for info gathering, or timely explosions.

## Ability — Volatile

When destroyed, roll its die twice, use the lower result as an Attack against all nearby non-mechanical targets.

## Tactics

Often deployed in trios to disrupt enemy formations.
