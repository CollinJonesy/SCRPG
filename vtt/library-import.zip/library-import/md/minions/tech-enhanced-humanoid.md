## Source page

404-405

## Description

Many aliens have technology far outstripping humanity's — unfortunately, often used as weaponry.

## Ability — Alien Gadgetry

+1 to Attack actions.

## Tactics

Work well in pairs, going after weaker combatants first.
