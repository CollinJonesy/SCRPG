## Source page

414-417

## Description

A mortal man who dabbled in extradimensional power against heroes like Fanatic and Argent Adept, imprisoned in the Void, now reappeared and twisted by his time there.

## Ability — Void Host

Whenever it takes a Hinder action, that penalty becomes Persistent and Exclusive; then Seer may end up anywhere else in the scene.

## Tactics

Steps in and out of the Void at a cost he cares little about; Hinders foes and moves with reckless abandon.
