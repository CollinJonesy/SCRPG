## Source page

408-410

## Description

Mostly spare parts by volume; built to cannibalize itself and other mechanical devices to repair fellow drones.

## Ability — Field Repair

Overcome action to repair another drone; on success, restores it to its starting die size (no minor twists required).

## Tactics

Avoid conflict, repairing the most damaged drones they can reach.
