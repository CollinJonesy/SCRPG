## Source page

408-410

## Description

An awesome truck for riding into a wasteland or driving over other vehicles.

## Ability — Run Over

After Attacking, may end up elsewhere in the scene.

## Tactics

Exists to protect passengers and get them places; avoids being under direct fire.
