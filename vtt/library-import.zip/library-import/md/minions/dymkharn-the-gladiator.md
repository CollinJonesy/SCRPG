## Source page

404-405

## Description

A former gladiator of the now-destroyed Bloodsworn Colosseum, stuck on Earth but still finds plenty of fights worth fighting.

## Ability — Twin Blades / Fearless

Twin Blades: can Attack up to two close targets with the same roll. Fearless: gains +1 to next Attack whenever he succeeds at his save.

## Tactics

Wants the biggest threat in the room, or ideally the biggest pair at once.
