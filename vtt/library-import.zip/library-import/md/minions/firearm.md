## Source page

414-417

## Description

Formerly a minor villain named Char; invasive experiments before OblivAeon granted more control over his power and even less grasp on morality.

## Ability — Unstable Ignition / Firewall

Rolls Attack die twice, uses higher (reduces die size by one if doubles). Uses a successful save roll as an Attack against his attacker.

## Tactics

Gets into the thick of combat, swinging arms of fire to ignite as many opponents as possible.
