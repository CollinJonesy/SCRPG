## Source page

412

## Description

The Magmarian warrior class, powered by embedded crystals; forms weapons/shields from the rock of their homes.

## Ability — Crystal Powered

Whenever it succeeds at its save, rolls its die as an Attack against all nearby non-Magmarian targets.

## Tactics

Wade into combat with relish; exist to fight so other Magmarians don't have to.
