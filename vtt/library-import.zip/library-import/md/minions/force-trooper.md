## Source page

406-407

## Description

Only the stoutest, strongest soldiers earn this distinction — heavy armor, powerful melee weapons.

## Ability — Tough

+2 to save roll.

## Tactics

Seek to take damage so less defensive allies have room to work; engage the most dangerous targets.
