## Source page

414-417

## Description

Speaks loudly, carries a big stick with nails in it. Nuance is not a strength.

## Ability — Big Fella

+1 to save rolls.

## Tactics

Gets to close range and stays there, letting other thugs handle the elaborate parts.
