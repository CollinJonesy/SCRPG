## Source page

411

## Description

Spiritual and logistical leader, coordinating city-building, crystal distribution, and little-understood rituals.

## Ability — Fiery Flock

As an action, roll its die twice, introduce Magmarian minions to the scene equal to the lower roll.

## Tactics

Stays out of the way until warrior classes arrive, but can bring them in faster.
