## Source page

406-407

## Description

Entry-level troops outfitted with special gear to compensate for inexperience.

## Ability — Protégé

+1 to actions if other minions/lieutenants are nearby, -1 if not.

## Tactics

Depend on other troops; stand firm and even rush opponents alongside allies, scatter without support.
