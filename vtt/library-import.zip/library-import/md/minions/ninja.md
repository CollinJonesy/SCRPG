## Source page

414-417

## Description

Sneaking unseen, striking from shadows, specialized weapons wielded with great skill.

## Ability — Stealthy Strike

+1 to Attacks/Hinders against targets unaware of them or who lost track of them.

## Tactics

Sticks to shadows, leaping in and out of combat to distract and damage without losing the stealth advantage.
